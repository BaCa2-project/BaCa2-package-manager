#include <iostream>

int main(){
    std::cout << "NIE" << std::endl;
}
